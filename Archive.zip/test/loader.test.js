/* eslint-disable @typescript-eslint/require-await */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable mocha/max-top-level-suites */

import * as codec from '@ipld/dag-cbor'
import { sha256 as hasher } from 'multiformats/hashes/sha2'
import { encode } from 'multiformats/block'

// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { assert, matches, equals, resetDirectory, notEquals } from './helpers.js'

import { parseCarFile } from '../dist/loader-helpers.esm.js'

import { Loader } from '../dist/loader.esm.js'
import { CRDT } from '../dist/crdt.esm.js'
import { TransactionBlockstore as Blockstore, Transaction } from '../dist/transaction.esm.js'

import { defaultConfig } from '../dist/store-fs.esm.js'

describe('basic Loader', function () {
  let loader, block, t
  beforeEach(async function () {
    await resetDirectory(defaultConfig.dataDir, 'test-loader-commit')
    t = new Transaction({})
    loader = new Loader('test-loader-commit')
    block = (await encode({
      value: { hello: 'world' },
      hasher,
      codec
    }))
    await t.put(block.cid, block.bytes)
  })
  it('should have an empty car log', function () {
    equals(loader.carLog.length, 0)
  })
  it('should commit', async function () {
    const carCid = await loader.commit(t, { head: [block.cid] })
    equals(loader.carLog.length, 1)
    const reader = await loader.loadCar(carCid)
    assert(reader)
    const parsed = await parseCarFile(reader)
    assert(parsed.cars)
    equals(parsed.cars.length, 0)
    assert(parsed.head)
  })
})

describe('basic Loader with two commits', function () {
  let loader, block, block2, t, carCid
  beforeEach(async function () {
    await resetDirectory(defaultConfig.dataDir, 'test-loader-two-commit')
    t = new Transaction({})
    loader = new Loader('test-loader-two-commit')
    block = (await encode({
      value: { hello: 'world' },
      hasher,
      codec
    }))
    await t.put(block.cid, block.bytes)
    await loader.commit(t, { head: [block.cid] })

    block2 = (await encode({
      value: { hello: 'universe' },
      hasher,
      codec
    }))

    await t.put(block2.cid, block2.bytes)
    carCid = await loader.commit(t, { head: [block2.cid] })
  })
  it('should have a car log', function () {
    equals(loader.carLog.length, 2)
  })
  it('should commit', async function () {
    const reader = await loader.loadCar(carCid)
    assert(reader)
    const parsed = await parseCarFile(reader)
    assert(parsed.cars)
    equals(parsed.compact.length, 0)
    equals(parsed.cars.length, 1)
    assert(parsed.head)
  })
  it('should compact', async function () {
    const compactCid = await loader.commit(t, { head: [block2.cid] }, true)
    equals(loader.carLog.length, 1)

    const reader = await loader.loadCar(compactCid)
    assert(reader)
    const parsed = await parseCarFile(reader)
    assert(parsed.cars)
    equals(parsed.compact.length, 2)
    equals(parsed.cars.length, 0)
    assert(parsed.head)
  })
  it('compact should erase old files', async function () {
    await loader.commit(t, { head: [block2.cid] }, true)
    // eslint-disable-next-line @typescript-eslint/no-unsafe-return
    const e = await loader.loadCar(carCid).catch(e => e)
    assert(e)
    matches(e.message, 'ENOENT')
  })
})

describe('Loader with a committed transaction', function () {
  /** @type {Loader} */
  let loader, blockstore, crdt, done
  const dbname = 'test-loader'
  beforeEach(async function () {
    await resetDirectory(defaultConfig.dataDir, 'test-loader')
    loader = new Loader(dbname)
    blockstore = new Blockstore(dbname, loader)
    crdt = new CRDT(dbname, blockstore)
    done = await crdt.bulk([{ key: 'foo', value: { foo: 'bar' } }])
  })
  it('should have a name', function () {
    equals(loader.name, dbname)
  })
  it('should commit a transaction', function () {
    assert(done.head)
    assert(done.car)
    equals(blockstore.transactions.size, 1)
    equals(loader.carLog.length, 1)
  })
  it('can load the car', async function () {
    const reader = await loader.loadCar(done.car)
    assert(reader)
    const parsed = await parseCarFile(reader)
    assert(parsed.cars)
    equals(parsed.cars.length, 0)
    assert(parsed.head)
  })
})

describe('Loader with two committed transactions', function () {
  /** @type {Loader} */
  let loader, blockstore, crdt, done1, done2
  const dbname = 'test-loader'
  beforeEach(async function () {
    await resetDirectory(defaultConfig.dataDir, 'test-loader')
    loader = new Loader(dbname)
    blockstore = new Blockstore(dbname, loader)
    crdt = new CRDT(dbname, blockstore)
    done1 = await crdt.bulk([{ key: 'apple', value: { foo: 'bar' } }])
    done2 = await crdt.bulk([{ key: 'orange', value: { foo: 'bar' } }])
  })
  it('should commit two transactions', function () {
    assert(done1.head)
    assert(done1.car)
    assert(done2.head)
    assert(done2.car)
    notEquals(done1.head, done2.head)
    notEquals(done1.car, done2.car)
    equals(blockstore.transactions.size, 2)
    equals(loader.carLog.length, 2)
    equals(loader.carLog.indexOf(done1.car), 0)
    equals(loader.carLog.indexOf(done2.car), 1)
  })
  it('can load the car', async function () {
    const reader = await loader.loadCar(done2.car)
    assert(reader)
    const parsed = await parseCarFile(reader)
    assert(parsed.cars)
    equals(parsed.cars.length, 1)
    assert(parsed.head)
  })
})

describe('Loader with many committed transactions', function () {
  /** @type {Loader} */
  let loader, blockstore, crdt
  const dbname = 'test-loader'
  const dones = []
  const count = 10
  beforeEach(async function () {
    await resetDirectory(defaultConfig.dataDir, 'test-loader')
    loader = new Loader(dbname)
    blockstore = new Blockstore(dbname, loader)
    crdt = new CRDT(dbname, blockstore)
    for (let i = 0; i < count; i++) {
      const did = await crdt.bulk([{ key: `apple${i}`, value: { foo: 'bar' } }])
      dones.push(did)
    }
  })
  it('should commit many transactions', function () {
    for (const done of dones) {
      assert(done.head)
      assert(done.car)
    }
    equals(blockstore.transactions.size, count)
    equals(loader.carLog.length, count)
  })
  it('can load the car', async function () {
    const reader = await loader.loadCar(dones[5].car)
    assert(reader)
    const parsed = await parseCarFile(reader)
    assert(parsed.cars)
    equals(parsed.cars.length, 5)
    assert(parsed.head)
  })
})
